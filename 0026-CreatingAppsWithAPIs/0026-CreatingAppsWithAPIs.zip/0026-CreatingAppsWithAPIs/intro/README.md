# rpsls-meetUp

Here are the starter and final files for our Rock, Paper, Scissor, Lizard, Spock meetup!
In this meetup, you will learn how to manipulate the DOM, and utilize a fetch to retrieve information from an API that will give us the CPU response in this game!
Hope you're all ready to have some fun!
