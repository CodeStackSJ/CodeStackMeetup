//
//  ViewController.swift
//  BirdApp
//
//  Created by Alexander Sosnov on 4/23/20.
//  Copyright © 2020 Alexander Sosnov. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

