# Custom Element Examples

1. [Basic](1-basic.html)
	- How to define & use a Custom Element

2. [Lifecycles](2-lifecycles.html)
	- How to automatically respond to certain actions by defining methods on your Custom Element

3. [Advanced](3-advanced.html)
	- How to write a complex Custom Element that performs a useful task
