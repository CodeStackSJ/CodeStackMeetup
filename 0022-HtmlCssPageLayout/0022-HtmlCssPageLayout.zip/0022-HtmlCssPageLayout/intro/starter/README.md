# Cascading Style Sheets with Joseph Racca and Anothay Chansy<br>
## Welcome back to part ✌️ of *Random Name Generator* ✨
► This is a continuation from <b> Wednesday, March 24, 2021
[CodeStack Virtual Meetup](https://www.meetup.com/CodeStack)  - Javascript Projects! <br> 
  🔸 Beginner JavaScript Project - Random Name Generator using Arrays by Alex Ato and Kenneth Martinez🧮<br>
 *Codestack Academy 3rd year daytime students'* 🌞<br> 
 <b>📢 If you've missed the last meetup, no worries. We will be providing you with the finished version of last meeting so you'll be able to start fresh with us 👍 <br>
   Here's a sneak of the last project with Alex and Kenneth ⬇️ 
   
   ![Alex and Ken](https://user-images.githubusercontent.com/61571099/113489332-7d0e2f00-9478-11eb-9085-a482a62cce82.png)

   <hr> 
   

  ### For this meetup, we will be showing you all how we can style this project a little more. <br>
   ► We will show you tips and trick, step-by-step, on how we can turn ⬆️ to ⬇️

  <img width="1391" alt="RaccaandChansy(css)" src="https://user-images.githubusercontent.com/61571099/113518784-451cef80-953d-11eb-854f-f4d3e9efcfbf.png">


   
   
