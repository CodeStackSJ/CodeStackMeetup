function x() {
	console.log('x');
}
function y() {
	console.log('y');
}
function z() {
	console.log('z');
}
console.group('one.js');
x();
y();
z();
console.groupEnd();