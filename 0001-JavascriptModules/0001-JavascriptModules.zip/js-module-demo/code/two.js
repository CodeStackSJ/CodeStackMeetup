console.group('two.js');
z();
y();
x();
console.groupEnd();
